//
// Created by 像我这样优秀的人 on 2020/11/13.
//

#ifndef HM5_CODE_MIDDLECODE_H
#define HM5_CODE_MIDDLECODE_H
#include "BasicBlock.h"
#include "vector"
using std::vector;
class middleCode{
public:
    vector<basicBlock> blockList;
};
#endif //HM5_CODE_MIDDLECODE_H
